module.exports = {
    rabbitConfig: {
        url: 'ampq://localhost',
        exchangeName: 'log'
    }
}
